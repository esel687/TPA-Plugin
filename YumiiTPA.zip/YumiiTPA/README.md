# YumiiTPA

TPA mit klickbarem Chat und GUI, Combat-Log mit roter Bossbar und Homes-System (max. 10, GUI) für **Paper 1.21.4**.

## Bauen

Voraussetzung: Java 21 und Maven, Internetzugang für `repo.papermc.io`.

```
mvn clean package
```

Die fertige Datei liegt danach unter `target/YumiiTPA.jar` und gehört in den `plugins/`-Ordner des Servers.

## Befehle

| Befehl | Beschreibung | Permission |
|---|---|---|
| `/tpa <Spieler>` | Du teleportierst dich zum Spieler | `yumiitpa.tpa` |
| `/tpahere <Spieler>` | Der Spieler teleportiert sich zu dir | `yumiitpa.tpahere` |
| `/tpaccept`, `/tpdeny` | Öffnet die Anfrage-GUI | `yumiitpa.tpa` |
| `/tpcancel` | Bricht deine ausgehende Anfrage ab | `yumiitpa.tpa` |
| `/sethome <Name>` | Home erstellen | `yumiitpa.sethome` |
| `/home <Name>` | Zu Home teleportieren | `yumiitpa.homes` |
| `/homes` | Homes-GUI | `yumiitpa.homes` |
| `/delhome <Name>`, `/home delete <Name>` | Home löschen | `yumiitpa.delhome` |
| `/home rename <Alt> <Neu>` | Home umbenennen | `yumiitpa.home.rename` |
| `/yumiitpa reload` | Config neu laden | `yumiitpa.admin` |

Spielerdaten liegen unter `plugins/YumiiTPA/players/<UUID>.yml`. Alle Einstellungen und Texte stehen in der `config.yml`.
