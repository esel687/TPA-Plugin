package de.yumii.tpa;

import de.yumii.tpa.models.Home;
import de.yumii.tpa.models.PlayerHomes;
import de.yumii.tpa.util.HomeNames;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PlayerHomesTest {

    private static Home home(String name) {
        return new Home(name, "world", 1.5, 64.0, -3.25, 90f, 10f);
    }

    @Test
    void addsUntilLimitIsReached() {
        PlayerHomes homes = new PlayerHomes();
        for (int i = 0; i < 10; i++) {
            assertEquals(PlayerHomes.AddResult.OK, homes.add(home("h" + i), 10));
        }
        assertEquals(PlayerHomes.AddResult.FULL, homes.add(home("extra"), 10));
        assertEquals(10, homes.size());
    }

    @Test
    void namesAreUniqueIgnoringCase() {
        PlayerHomes homes = new PlayerHomes();
        assertEquals(PlayerHomes.AddResult.OK, homes.add(home("Base"), 10));
        assertEquals(PlayerHomes.AddResult.DUPLICATE, homes.add(home("base"), 10));
        assertNotNull(homes.get("BASE"));
    }

    @Test
    void removeIgnoresCaseAndReturnsHome() {
        PlayerHomes homes = new PlayerHomes();
        homes.add(home("Base"), 10);
        assertEquals("Base", homes.remove("bAsE").name());
        assertNull(homes.remove("base"));
        assertEquals(0, homes.size());
    }

    @Test
    void renameKeepsPositionAndOrder() {
        PlayerHomes homes = new PlayerHomes();
        homes.add(home("a"), 10);
        homes.add(home("Base"), 10);
        homes.add(home("c"), 10);
        assertEquals(PlayerHomes.RenameResult.OK, homes.rename("base", "NeueBase"));

        List<Home> all = homes.all();
        assertEquals(List.of("a", "NeueBase", "c"), all.stream().map(Home::name).toList());
        Home renamed = homes.get("neuebase");
        assertEquals(1.5, renamed.x());
        assertEquals(64.0, renamed.y());
        assertEquals(-3.25, renamed.z());
        assertEquals(90f, renamed.yaw());
        assertEquals(10f, renamed.pitch());
        assertNull(homes.get("base"));
    }

    @Test
    void renameFailsForMissingOrTakenNames() {
        PlayerHomes homes = new PlayerHomes();
        homes.add(home("a"), 10);
        homes.add(home("b"), 10);
        assertEquals(PlayerHomes.RenameResult.NOT_FOUND, homes.rename("x", "y"));
        assertEquals(PlayerHomes.RenameResult.DUPLICATE, homes.rename("a", "B"));
    }

    @Test
    void renameAllowsChangingOnlyTheCase() {
        PlayerHomes homes = new PlayerHomes();
        homes.add(home("base"), 10);
        assertEquals(PlayerHomes.RenameResult.OK, homes.rename("base", "Base"));
        assertEquals("Base", homes.get("base").name());
    }

    @Test
    void homeNameValidation() {
        assertTrue(HomeNames.isValid("Base"));
        assertTrue(HomeNames.isValid("my_home-2"));
        assertFalse(HomeNames.isValid(""));
        assertFalse(HomeNames.isValid(null));
        assertFalse(HomeNames.isValid("with space"));
        assertFalse(HomeNames.isValid("a.b"));
        assertFalse(HomeNames.isValid("12345678901234567"));
        assertFalse(HomeNames.isValid("Rename"));
        assertFalse(HomeNames.isValid("delete"));
        assertEquals("base", HomeNames.key("BaSe"));
    }

    @Test
    void homeValidityRejectsBrokenData() {
        assertTrue(home("ok").isValid());
        assertFalse(new Home("x", "", 0, 0, 0, 0f, 0f).isValid());
        assertFalse(new Home("x", "world", Double.NaN, 0, 0, 0f, 0f).isValid());
    }
}
