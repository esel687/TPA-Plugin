package de.yumii.tpa.models;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

/** Eine offene Teleportationsanfrage. Existiert nur im Speicher, solange sie offen ist. */
public final class TpaRequest {

    public enum Type { TPA, TPAHERE }

    private final UUID id = UUID.randomUUID();
    private final UUID sender;
    private final UUID target;
    private final String senderName;
    private final String targetName;
    private final Type type;
    private BukkitTask expiryTask;

    public TpaRequest(Player sender, Player target, Type type) {
        this.sender = sender.getUniqueId();
        this.target = target.getUniqueId();
        this.senderName = sender.getName();
        this.targetName = target.getName();
        this.type = type;
    }

    public UUID id() { return id; }

    public UUID sender() { return sender; }

    public UUID target() { return target; }

    public String senderName() { return senderName; }

    public String targetName() { return targetName; }

    public Type type() { return type; }

    public void setExpiryTask(BukkitTask task) { this.expiryTask = task; }

    public void cancelExpiryTask() {
        if (expiryTask != null) {
            expiryTask.cancel();
            expiryTask = null;
        }
    }
}
