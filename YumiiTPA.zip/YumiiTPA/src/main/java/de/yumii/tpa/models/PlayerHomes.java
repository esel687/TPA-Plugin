package de.yumii.tpa.models;

import de.yumii.tpa.util.HomeNames;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Die Homes eines Spielers. Reine Logik ohne Bukkit-Abhängigkeit zur Laufzeit,
 * dadurch ohne Server testbar. Namen sind unabhängig von Groß-/Kleinschreibung eindeutig;
 * die Reihenfolge bleibt erhalten.
 */
public final class PlayerHomes {

    public enum AddResult { OK, FULL, DUPLICATE }

    public enum RenameResult { OK, NOT_FOUND, DUPLICATE }

    private final LinkedHashMap<String, Home> homes = new LinkedHashMap<>();

    public AddResult add(Home home, int max) {
        String key = HomeNames.key(home.name());
        if (homes.containsKey(key)) {
            return AddResult.DUPLICATE;
        }
        if (homes.size() >= max) {
            return AddResult.FULL;
        }
        homes.put(key, home);
        return AddResult.OK;
    }

    /** Fügt ein geladenes Home ohne Limit-Prüfung ein (Doppelte werden ignoriert). */
    public boolean putLoaded(Home home) {
        return homes.putIfAbsent(HomeNames.key(home.name()), home) == null;
    }

    public Home get(String name) {
        return name == null ? null : homes.get(HomeNames.key(name));
    }

    public Home remove(String name) {
        return name == null ? null : homes.remove(HomeNames.key(name));
    }

    public RenameResult rename(String oldName, String newName) {
        String oldKey = HomeNames.key(oldName);
        String newKey = HomeNames.key(newName);
        Home old = homes.get(oldKey);
        if (old == null) {
            return RenameResult.NOT_FOUND;
        }
        if (!oldKey.equals(newKey) && homes.containsKey(newKey)) {
            return RenameResult.DUPLICATE;
        }
        LinkedHashMap<String, Home> rebuilt = new LinkedHashMap<>();
        for (Map.Entry<String, Home> entry : homes.entrySet()) {
            if (entry.getKey().equals(oldKey)) {
                rebuilt.put(newKey, old.withName(newName));
            } else {
                rebuilt.put(entry.getKey(), entry.getValue());
            }
        }
        homes.clear();
        homes.putAll(rebuilt);
        return RenameResult.OK;
    }

    public List<Home> all() {
        return new ArrayList<>(homes.values());
    }

    public int size() {
        return homes.size();
    }
}
