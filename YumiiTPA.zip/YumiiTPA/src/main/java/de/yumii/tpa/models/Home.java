package de.yumii.tpa.models;

import org.bukkit.Location;

/**
 * Ein gespeichertes Home. Die Welt wird nur als Name gespeichert, damit auch Homes in
 * (noch) nicht geladenen Welten erhalten bleiben.
 */
public record Home(String name, String world, double x, double y, double z, float yaw, float pitch) {

    public static Home of(String name, Location location) {
        return new Home(name, location.getWorld().getName(),
                location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch());
    }

    public Home withName(String newName) {
        return new Home(newName, world, x, y, z, yaw, pitch);
    }

    /** Prüft, ob alle Werte gültig sind (keine NaN/Infinity, Welt vorhanden). */
    public boolean isValid() {
        return name != null && !name.isBlank()
                && world != null && !world.isBlank()
                && Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && Float.isFinite(yaw) && Float.isFinite(pitch);
    }
}
