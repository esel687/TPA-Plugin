package de.yumii.tpa;

import de.yumii.tpa.commands.AdminCommand;
import de.yumii.tpa.commands.HomeCommand;
import de.yumii.tpa.commands.TpaCommand;
import de.yumii.tpa.config.Settings;
import de.yumii.tpa.gui.GuiManager;
import de.yumii.tpa.listeners.CombatListener;
import de.yumii.tpa.listeners.GuiListener;
import de.yumii.tpa.listeners.PlayerListener;
import de.yumii.tpa.managers.CombatManager;
import de.yumii.tpa.managers.HomeManager;
import de.yumii.tpa.managers.TeleportManager;
import de.yumii.tpa.managers.TpaManager;
import de.yumii.tpa.util.Messages;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Locale;

/**
 * YumiiTPA - TPA mit GUI, Combat-Log mit Bossbar und Homes-System.
 *
 * <p>Architektur: {@link TeleportManager} ist der einzige Weg zu einer Teleportation
 * (Countdown, Bewegungs-/Combat-/Tod-/Logout-Prüfung). {@link TpaManager} verwaltet Anfragen,
 * {@link HomeManager} die Homes, {@link CombatManager} Combat + Bossbar, {@link GuiManager}
 * die Inventare. Listener und Commands sind dünne Schichten darüber.</p>
 */
public final class YumiiTPA extends JavaPlugin {

    private Settings settings;
    private Messages messages;
    private HomeManager homes;
    private CombatManager combat;
    private TeleportManager teleports;
    private TpaManager tpa;
    private GuiManager gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = Settings.load(getConfig());
        messages = new Messages(this);
        homes = new HomeManager(this);
        combat = new CombatManager(this);
        teleports = new TeleportManager(this);
        tpa = new TpaManager(this);
        gui = new GuiManager(this);

        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CombatListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(this), this);

        TpaCommand tpaCommand = new TpaCommand(this);
        for (String name : List.of("tpa", "tpahere", "tpaccept", "tpdeny", "tpcancel", "tpagui")) {
            bind(name, tpaCommand);
        }
        HomeCommand homeCommand = new HomeCommand(this);
        for (String name : List.of("sethome", "home", "homes", "delhome")) {
            bind(name, homeCommand);
        }
        bind("yumiitpa", new AdminCommand(this));

        // Bei /reload bereits online befindliche Spieler vorladen.
        for (Player player : Bukkit.getOnlinePlayers()) {
            homes.get(player.getUniqueId());
        }
    }

    @Override
    public void onDisable() {
        if (tpa != null) {
            tpa.shutdown();
        }
        if (teleports != null) {
            teleports.shutdown();
        }
        if (combat != null) {
            combat.shutdown();
        }
        if (gui != null) {
            gui.closeAll();
        }
    }

    private void bind(String name, TabExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Befehl /" + name + " fehlt in der plugin.yml!");
            return;
        }
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    /** Lädt die Konfiguration neu. Fehlende oder ungültige Werte fallen auf Standardwerte zurück. */
    public void reload() {
        reloadConfig();
        settings = Settings.load(getConfig());
        if (!settings.combatEnabled) {
            combat.shutdown();
        }
    }

    /** Spielt einen in der Config unter sounds.&lt;key&gt; eingestellten Sound ab. */
    public void playSound(Player player, String key) {
        FileConfiguration config = getConfig();
        if (!config.getBoolean("sounds.enabled", true)) {
            return;
        }
        String name = config.getString("sounds." + key);
        if (name == null || name.isBlank()) {
            return;
        }
        try {
            player.playSound(Sound.sound(Key.key(name.trim().toLowerCase(Locale.ROOT)), Sound.Source.MASTER, 1.0f, 1.0f));
        } catch (RuntimeException ignored) {
            // Ungültiger Sound-Schlüssel in der Config: einfach keinen Sound abspielen.
        }
    }

    public Settings settings() { return settings; }

    public Messages messages() { return messages; }

    public HomeManager homes() { return homes; }

    public CombatManager combat() { return combat; }

    public TeleportManager teleports() { return teleports; }

    public TpaManager tpa() { return tpa; }

    public GuiManager gui() { return gui; }
}
