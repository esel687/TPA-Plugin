package de.yumii.tpa.listeners;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.gui.GuiManager;
import de.yumii.tpa.models.Home;
import de.yumii.tpa.models.PlayerHomes;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.List;

/**
 * Schützt alle Plugin-GUIs vor jeglicher Item-Bewegung (Klick, Shift-Klick, Hotkeys, Drag)
 * und verarbeitet die Klicks auf die Buttons.
 */
public final class GuiListener implements Listener {

    private final YumiiTPA plugin;

    public GuiListener(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();
        if (!(holder instanceof GuiManager.TpaHolder) && !(holder instanceof GuiManager.HomesHolder)) {
            return;
        }
        // Alles blockieren, auch Klicks im eigenen Inventar (Shift-Klick, Hotkeys, Doppelklick).
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() != top) {
            return;
        }
        ClickType click = event.getClick();
        if (click != ClickType.LEFT && click != ClickType.RIGHT) {
            return;
        }
        int slot = event.getSlot();

        if (holder instanceof GuiManager.TpaHolder tpaHolder) {
            handleTpaClick(player, tpaHolder, slot);
        } else if (holder instanceof GuiManager.HomesHolder homesHolder) {
            handleHomesClick(player, homesHolder, slot);
        }
    }

    private void handleTpaClick(Player player, GuiManager.TpaHolder holder, int slot) {
        if (!holder.viewer().equals(player.getUniqueId())) {
            return;
        }
        if (slot != GuiManager.TPA_ACCEPT_SLOT && slot != GuiManager.TPA_DENY_SLOT) {
            return;
        }
        boolean accept = slot == GuiManager.TPA_ACCEPT_SLOT;
        // GUI zuerst schließen: weitere Klicks können die Anfrage nicht mehr bedienen.
        player.closeInventory();
        plugin.tpa().decide(player, holder.requestId(), accept);
    }

    private void handleHomesClick(Player player, GuiManager.HomesHolder holder, int slot) {
        if (!holder.viewer().equals(player.getUniqueId())) {
            return;
        }
        int index = -1;
        for (int i = 0; i < GuiManager.HOME_SLOTS.length; i++) {
            if (GuiManager.HOME_SLOTS[i] == slot) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            return;
        }
        PlayerHomes playerHomes = plugin.homes().get(player.getUniqueId());
        List<Home> homes = playerHomes.all();
        if (index < homes.size()) {
            Home home = homes.get(index);
            player.closeInventory();
            plugin.homes().teleport(player, home);
        } else if (index < plugin.settings().maxHomes) {
            plugin.messages().send(player, "home.slot-free");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (GuiManager.isPluginInventory(event.getView().getTopInventory())) {
            event.setCancelled(true);
        }
    }
}
