package de.yumii.tpa.managers;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.models.TpaRequest;
import de.yumii.tpa.util.Messages;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Verwaltet offene Teleportationsanfragen. Eine Anfrage gilt nur, solange sie in der Map steht;
 * jede Entscheidung (annehmen, ablehnen, abbrechen, Ablauf, Logout) entfernt sie genau einmal.
 */
public final class TpaManager {

    private final YumiiTPA plugin;
    private final Map<UUID, TpaRequest> requests = new LinkedHashMap<>();

    public TpaManager(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    public TpaRequest get(UUID requestId) {
        return requests.get(requestId);
    }

    public TpaRequest findOutgoing(UUID sender) {
        for (TpaRequest request : requests.values()) {
            if (request.sender().equals(sender)) {
                return request;
            }
        }
        return null;
    }

    /** Neueste eingehende Anfrage (optional von einem bestimmten Absender). */
    public TpaRequest findIncoming(UUID target, String senderName) {
        TpaRequest found = null;
        for (TpaRequest request : requests.values()) {
            if (!request.target().equals(target)) {
                continue;
            }
            if (senderName != null && !request.senderName().equalsIgnoreCase(senderName)) {
                continue;
            }
            found = request;
        }
        return found;
    }

    public List<String> incomingSenderNames(UUID target) {
        List<String> names = new ArrayList<>();
        for (TpaRequest request : requests.values()) {
            if (request.target().equals(target)) {
                names.add(request.senderName());
            }
        }
        return names;
    }

    // ---------------------------------------------------------------- Senden

    public void send(Player sender, Player target, TpaRequest.Type type) {
        Messages messages = plugin.messages();
        if (!plugin.settings().tpaEnabled) {
            messages.send(sender, "feature-disabled");
            return;
        }
        if (sender.getUniqueId().equals(target.getUniqueId())) {
            messages.send(sender, "tpa.self");
            return;
        }
        TpaRequest existing = findOutgoing(sender.getUniqueId());
        if (existing != null) {
            if (existing.target().equals(target.getUniqueId())) {
                messages.send(sender, "tpa.duplicate");
                return;
            }
            // Eine neue Anfrage an jemand anderen ersetzt die alte ausgehende Anfrage.
            finish(existing);
            Player oldTarget = Bukkit.getPlayer(existing.target());
            if (oldTarget != null) {
                messages.send(oldTarget, "tpa.replaced", "player", sender.getName());
                plugin.gui().closeTpa(oldTarget.getUniqueId(), existing.id());
            }
        }

        TpaRequest request = new TpaRequest(sender, target, type);
        long ticks = plugin.settings().tpaTimeoutSeconds * 20L;
        request.setExpiryTask(Bukkit.getScheduler().runTaskLater(plugin, () -> expire(request.id()), ticks));
        requests.put(request.id(), request);

        messages.send(sender, "tpa.sent");
        target.sendMessage(buildRequestMessage(request));
        plugin.playSound(target, "request");
    }

    private Component buildRequestMessage(TpaRequest request) {
        Messages messages = plugin.messages();
        String command = "/tpagui " + request.id();
        Component accept = Component.text(messages.raw("messages.tpa.button-accept"), NamedTextColor.GREEN, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand(command))
                .hoverEvent(HoverEvent.showText(messages.component("messages.tpa.hover-accept")));
        Component deny = Component.text(messages.raw("messages.tpa.button-deny"), NamedTextColor.RED, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand(command))
                .hoverEvent(HoverEvent.showText(messages.component("messages.tpa.hover-deny")));
        String key = request.type() == TpaRequest.Type.TPA ? "tpa.received" : "tpa.received-here";
        Component base = messages.prefixed(key, "player", request.senderName());
        return base
                .replaceText(TextReplacementConfig.builder().matchLiteral("{accept}").replacement(accept).build())
                .replaceText(TextReplacementConfig.builder().matchLiteral("{deny}").replacement(deny).build());
    }

    // ------------------------------------------------------ Entscheidungen

    /** Wird von der GUI aufgerufen. Prüft die Anfrage bei jedem Klick erneut. */
    public void decide(Player player, UUID requestId, boolean accept) {
        TpaRequest request = requests.get(requestId);
        if (request == null || !request.target().equals(player.getUniqueId())) {
            plugin.messages().send(player, "tpa.request-invalid");
            return;
        }
        if (accept) {
            accept(player, request);
        } else {
            deny(player, request);
        }
    }

    private void accept(Player acceptor, TpaRequest request) {
        Messages messages = plugin.messages();
        CombatManager combat = plugin.combat();
        if (!plugin.settings().tpaEnabled) {
            messages.send(acceptor, "feature-disabled");
            return;
        }
        if (combat.isInCombat(acceptor.getUniqueId())) {
            messages.send(acceptor, "tpa.combat-accept");
            plugin.playSound(acceptor, "deny");
            return;
        }
        Player requester = Bukkit.getPlayer(request.sender());
        if (requester == null) {
            finish(request);
            messages.send(acceptor, "tpa.sender-offline");
            return;
        }
        // /tpa: Anfragender geht zum Empfänger. /tpahere: Empfänger geht zum Anfragenden.
        boolean requesterTeleports = request.type() == TpaRequest.Type.TPA;
        Player teleporter = requesterTeleports ? requester : acceptor;
        Player destination = requesterTeleports ? acceptor : requester;

        if (combat.isInCombat(teleporter.getUniqueId())) {
            messages.send(acceptor, "tpa.sender-in-combat", "player", teleporter.getName());
            plugin.playSound(acceptor, "deny");
            return;
        }
        if (plugin.teleports().isTeleporting(teleporter.getUniqueId())) {
            messages.send(acceptor, "tpa.teleport-running", "player", teleporter.getName());
            return;
        }

        finish(request);
        messages.send(acceptor, "tpa.accepted-self", "player", requester.getName());
        messages.send(requester, "tpa.accepted-other", "player", acceptor.getName());
        plugin.playSound(acceptor, "accept");
        plugin.playSound(requester, "accept");

        UUID destinationId = destination.getUniqueId();
        plugin.teleports().start(teleporter, () -> {
            Player current = Bukkit.getPlayer(destinationId);
            return current == null ? null : current.getLocation();
        }, destinationId, "tp.combat");
    }

    private void deny(Player target, TpaRequest request) {
        Messages messages = plugin.messages();
        finish(request);
        messages.send(target, "tpa.denied-self", "player", request.senderName());
        plugin.playSound(target, "deny");
        Player requester = Bukkit.getPlayer(request.sender());
        if (requester != null) {
            messages.send(requester, "tpa.denied-other", "player", target.getName());
            plugin.playSound(requester, "deny");
        }
    }

    /** /tpcancel */
    public void cancelOutgoing(Player sender) {
        TpaRequest request = findOutgoing(sender.getUniqueId());
        if (request == null) {
            plugin.messages().send(sender, "tpa.no-outgoing");
            return;
        }
        finish(request);
        plugin.messages().send(sender, "tpa.cancelled-self", "player", request.targetName());
        Player target = Bukkit.getPlayer(request.target());
        if (target != null) {
            plugin.messages().send(target, "tpa.cancelled-other", "player", sender.getName());
            plugin.gui().closeTpa(target.getUniqueId(), request.id());
        }
    }

    // ------------------------------------------------- Ablauf und Aufräumen

    private void expire(UUID requestId) {
        TpaRequest request = requests.get(requestId);
        if (request == null) {
            return;
        }
        finish(request);
        Player sender = Bukkit.getPlayer(request.sender());
        Player target = Bukkit.getPlayer(request.target());
        if (sender != null) {
            plugin.messages().send(sender, "tpa.expired-sender", "player", request.targetName());
        }
        if (target != null) {
            plugin.messages().send(target, "tpa.expired-target", "player", request.senderName());
            plugin.gui().closeTpa(target.getUniqueId(), request.id());
        }
    }

    /** Entfernt alle Anfragen eines Spielers, der den Server verlässt. */
    public void onQuit(Player player) {
        UUID id = player.getUniqueId();
        for (TpaRequest request : new ArrayList<>(requests.values())) {
            boolean isSender = request.sender().equals(id);
            boolean isTarget = request.target().equals(id);
            if (!isSender && !isTarget) {
                continue;
            }
            finish(request);
            UUID otherId = isSender ? request.target() : request.sender();
            Player other = Bukkit.getPlayer(otherId);
            if (other != null) {
                plugin.messages().send(other, "tpa.partner-left", "player", player.getName());
                plugin.gui().closeTpa(otherId, request.id());
            }
        }
    }

    public void shutdown() {
        for (TpaRequest request : new ArrayList<>(requests.values())) {
            finish(request);
        }
    }

    /** Beendet eine Anfrage genau einmal: aus der Map nehmen und den Ablauf-Task stoppen. */
    private void finish(TpaRequest request) {
        requests.remove(request.id());
        request.cancelExpiryTask();
    }
}
