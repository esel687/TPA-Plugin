package de.yumii.tpa.managers;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.util.Text;
import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Combat-Zustände mit roter Bossbar. Es läuft höchstens ein einziger Task, und nur solange
 * mindestens ein Spieler im Combat ist.
 */
public final class CombatManager {

    private static final long UPDATE_PERIOD_TICKS = 5L;

    private static final class State {
        long endMillis;
        final BossBar bar;
        int lastSeconds = -1;

        State(BossBar bar) {
            this.bar = bar;
        }
    }

    private final YumiiTPA plugin;
    private final Map<UUID, State> states = new HashMap<>();
    private BukkitTask task;

    public CombatManager(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    public boolean isInCombat(UUID id) {
        if (!plugin.settings().combatEnabled) {
            return false;
        }
        State state = states.get(id);
        return state != null && state.endMillis > System.currentTimeMillis();
    }

    /** Versetzt beide Spieler in Combat bzw. verlängert ihn auf die volle Dauer. */
    public void tag(Player attacker, Player victim) {
        if (!plugin.settings().combatEnabled) {
            return;
        }
        touch(attacker);
        touch(victim);
        plugin.teleports().cancel(attacker.getUniqueId(), TeleportManager.CancelReason.COMBAT);
        plugin.teleports().cancel(victim.getUniqueId(), TeleportManager.CancelReason.COMBAT);
        ensureTask();
    }

    private void touch(Player player) {
        long now = System.currentTimeMillis();
        long end = now + plugin.settings().combatSeconds * 1000L;
        State state = states.get(player.getUniqueId());
        if (state == null) {
            BossBar bar = BossBar.bossBar(Text.color(""), 1.0f, BossBar.Color.RED, BossBar.Overlay.PROGRESS);
            state = new State(bar);
            state.endMillis = end;
            states.put(player.getUniqueId(), state);
            updateBar(state, now);
            player.showBossBar(bar);
            plugin.messages().send(player, "combat.entered");
        } else {
            state.endMillis = end;
            updateBar(state, now);
        }
    }

    private void updateBar(State state, long now) {
        long totalMillis = plugin.settings().combatSeconds * 1000L;
        long remaining = Math.max(0L, state.endMillis - now);
        float progress = Math.max(0f, Math.min(1f, remaining / (float) totalMillis));
        state.bar.progress(progress);
        int seconds = (int) Math.ceil(remaining / 1000.0);
        if (seconds != state.lastSeconds) {
            state.lastSeconds = seconds;
            state.bar.name(plugin.messages().component("combat.bossbar-text",
                    "seconds", String.valueOf(seconds), "unit", Text.unit(seconds)));
        }
    }

    private void ensureTask() {
        if (task == null && !states.isEmpty()) {
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, UPDATE_PERIOD_TICKS, UPDATE_PERIOD_TICKS);
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, State>> iterator = states.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, State> entry = iterator.next();
            Player player = Bukkit.getPlayer(entry.getKey());
            State state = entry.getValue();
            if (player == null) {
                iterator.remove();
                continue;
            }
            if (now >= state.endMillis) {
                iterator.remove();
                player.hideBossBar(state.bar);
                plugin.messages().send(player, "combat.ended");
                continue;
            }
            updateBar(state, now);
        }
        if (states.isEmpty() && task != null) {
            task.cancel();
            task = null;
        }
    }

    /** Beendet den Combat eines Spielers sofort (z. B. bei Tod). */
    public void end(Player player) {
        State state = states.remove(player.getUniqueId());
        if (state != null) {
            player.hideBossBar(state.bar);
        }
    }

    /** Logout: Zustand und Bossbar aufräumen, optional bestrafen. */
    public void onQuit(Player player) {
        State state = states.remove(player.getUniqueId());
        if (state == null) {
            return;
        }
        player.hideBossBar(state.bar);
        boolean stillActive = state.endMillis > System.currentTimeMillis();
        if (stillActive && plugin.settings().killOnQuit && plugin.settings().combatEnabled && !player.isDead()) {
            player.setHealth(0.0);
        }
    }

    /** Entfernt alle Zustände, Bossbars und den Task. */
    public void shutdown() {
        for (Map.Entry<UUID, State> entry : states.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null) {
                player.hideBossBar(entry.getValue().bar);
            }
        }
        states.clear();
        if (task != null) {
            task.cancel();
            task = null;
        }
    }
}
