package de.yumii.tpa.commands;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.models.Home;
import de.yumii.tpa.models.PlayerHomes;
import de.yumii.tpa.util.HomeNames;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** /sethome, /home (inkl. rename und delete), /homes und /delhome. */
public final class HomeCommand implements TabExecutor {

    private final YumiiTPA plugin;

    public HomeCommand(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        if (!plugin.settings().homesEnabled) {
            plugin.messages().send(player, "feature-disabled");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "sethome" -> setHome(player, args);
            case "delhome" -> deleteHome(player, args, "home.usage-delhome");
            case "homes" -> openGui(player);
            case "home" -> home(player, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private boolean hasPermission(Player player, String permission) {
        if (player.hasPermission(permission)) {
            return true;
        }
        plugin.messages().send(player, "no-permission");
        return false;
    }

    private void openGui(Player player) {
        if (hasPermission(player, "yumiitpa.homes")) {
            plugin.gui().openHomes(player);
        }
    }

    private void home(Player player, String[] args) {
        if (args.length == 0) {
            openGui(player);
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("rename")) {
            renameHome(player, args);
            return;
        }
        if (sub.equals("delete")) {
            deleteHome(player, Arrays.copyOfRange(args, 1, args.length), "home.usage-delhome");
            return;
        }
        if (!hasPermission(player, "yumiitpa.homes")) {
            return;
        }
        Home home = plugin.homes().get(player.getUniqueId()).get(args[0]);
        if (home == null) {
            plugin.messages().send(player, "home.not-found");
            return;
        }
        plugin.homes().teleport(player, home);
    }

    private void setHome(Player player, String[] args) {
        if (!hasPermission(player, "yumiitpa.sethome")) {
            return;
        }
        if (args.length != 1) {
            plugin.messages().send(player, "home.usage-sethome");
            return;
        }
        String name = args[0];
        if (!HomeNames.isValid(name)) {
            plugin.messages().send(player, "home.invalid-name");
            return;
        }
        PlayerHomes homes = plugin.homes().get(player.getUniqueId());
        int max = plugin.settings().maxHomes;
        PlayerHomes.AddResult result = homes.add(Home.of(name, player.getLocation()), max);
        switch (result) {
            case DUPLICATE -> plugin.messages().send(player, "home.exists");
            case FULL -> plugin.messages().send(player, "home.full", "max", String.valueOf(max));
            case OK -> {
                if (plugin.homes().save(player.getUniqueId())) {
                    plugin.messages().send(player, "home.created", "name", name);
                } else {
                    plugin.messages().send(player, "home.save-failed");
                }
                plugin.gui().refreshHomes(player);
            }
        }
    }

    private void deleteHome(Player player, String[] args, String usageKey) {
        if (!hasPermission(player, "yumiitpa.delhome")) {
            return;
        }
        if (args.length != 1) {
            plugin.messages().send(player, usageKey);
            return;
        }
        PlayerHomes homes = plugin.homes().get(player.getUniqueId());
        Home removed = homes.remove(args[0]);
        if (removed == null) {
            plugin.messages().send(player, "home.not-found");
            return;
        }
        if (plugin.homes().save(player.getUniqueId())) {
            plugin.messages().send(player, "home.deleted", "name", removed.name());
        } else {
            plugin.messages().send(player, "home.save-failed");
        }
        plugin.gui().refreshHomes(player);
    }

    private void renameHome(Player player, String[] args) {
        if (!hasPermission(player, "yumiitpa.home.rename")) {
            return;
        }
        if (args.length != 3) {
            plugin.messages().send(player, "home.usage-rename");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        PlayerHomes homes = plugin.homes().get(player.getUniqueId());
        Home existing = homes.get(oldName);
        if (existing == null) {
            plugin.messages().send(player, "home.not-found");
            return;
        }
        if (!HomeNames.isValid(newName)) {
            plugin.messages().send(player, "home.invalid-name");
            return;
        }
        PlayerHomes.RenameResult result = homes.rename(oldName, newName);
        switch (result) {
            case NOT_FOUND -> plugin.messages().send(player, "home.not-found");
            case DUPLICATE -> plugin.messages().send(player, "home.exists");
            case OK -> {
                if (plugin.homes().save(player.getUniqueId())) {
                    plugin.messages().send(player, "home.renamed", "old", existing.name(), "new", newName);
                } else {
                    plugin.messages().send(player, "home.save-failed");
                }
                plugin.gui().refreshHomes(player);
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player)) {
            return List.of();
        }
        String name = command.getName().toLowerCase(Locale.ROOT);
        List<String> candidates = new ArrayList<>();
        String current;
        if (name.equals("delhome") && args.length == 1) {
            current = args[0];
            addHomeNames(player, candidates);
        } else if (name.equals("home") && args.length == 1) {
            current = args[0];
            candidates.add("rename");
            candidates.add("delete");
            addHomeNames(player, candidates);
        } else if (name.equals("home") && args.length == 2
                && (args[0].equalsIgnoreCase("rename") || args[0].equalsIgnoreCase("delete"))) {
            current = args[1];
            addHomeNames(player, candidates);
        } else {
            return List.of();
        }
        String prefix = current.toLowerCase(Locale.ROOT);
        candidates.removeIf(entry -> !entry.toLowerCase(Locale.ROOT).startsWith(prefix));
        return candidates;
    }

    private void addHomeNames(Player player, List<String> target) {
        for (Home home : plugin.homes().get(player.getUniqueId()).all()) {
            target.add(home.name());
        }
    }
}
