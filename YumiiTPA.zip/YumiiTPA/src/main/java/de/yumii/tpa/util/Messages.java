package de.yumii.tpa.util;

import de.yumii.tpa.YumiiTPA;
import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

/**
 * Liest alle Texte live aus der config.yml (fehlende Werte kommen aus der mitgelieferten
 * Standard-Config). Platzhalter werden als Schlüssel/Wert-Paare übergeben.
 */
public final class Messages {

    private final YumiiTPA plugin;

    public Messages(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    public String raw(String path) {
        return plugin.getConfig().getString(path, "&c[Fehlender Text: " + path + "]");
    }

    public static String fill(String text, String... kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) {
            text = text.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return text;
    }

    /** Text an beliebigem Config-Pfad, ohne Präfix. */
    public Component component(String path, String... kv) {
        return Text.color(fill(raw(path), kv));
    }

    /** Nachricht aus dem Bereich "messages." inklusive Präfix. */
    public Component prefixed(String key, String... kv) {
        return Text.color(raw("messages.prefix") + " " + fill(raw("messages." + key), kv));
    }

    public void send(CommandSender receiver, String key, String... kv) {
        receiver.sendMessage(prefixed(key, kv));
    }

    /** Lore-Zeilen (Liste) aus der Config, ohne Kursivschrift. */
    public List<Component> lore(String path, String... kv) {
        List<Component> result = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList(path)) {
            result.add(Text.noItalic(fill(line, kv)));
        }
        return result;
    }
}
