package de.yumii.tpa.util;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Validierung und Normalisierung von Home-Namen. */
public final class HomeNames {

    public static final int MAX_LENGTH = 16;

    private static final Pattern VALID = Pattern.compile("[A-Za-z0-9_\\-]{1,16}");
    private static final Set<String> RESERVED = Set.of("rename", "delete");

    private HomeNames() {
    }

    public static boolean isValid(String name) {
        return name != null
                && VALID.matcher(name).matches()
                && !RESERVED.contains(name.toLowerCase(Locale.ROOT));
    }

    /** Schlüssel für die Eindeutigkeit (unabhängig von Groß-/Kleinschreibung). */
    public static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }
}
