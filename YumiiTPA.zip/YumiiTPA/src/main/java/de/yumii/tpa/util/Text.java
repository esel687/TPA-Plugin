package de.yumii.tpa.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/** Kleine Helfer für Adventure-Komponenten mit &-Farbcodes. */
public final class Text {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private Text() {
    }

    /** Wandelt &-Farbcodes (und §-Codes) in eine Komponente um. */
    public static Component color(String input) {
        return LEGACY.deserialize(input == null ? "" : input.replace('&', '§'));
    }

    /** Wie {@link #color(String)}, aber ohne die Standard-Kursivschrift von Item-Texten. */
    public static Component noItalic(String input) {
        return color(input).decoration(TextDecoration.ITALIC, false);
    }

    public static String unit(int seconds) {
        return seconds == 1 ? "Sekunde" : "Sekunden";
    }
}
