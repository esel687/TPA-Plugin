package de.yumii.tpa.managers;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.util.Messages;
import de.yumii.tpa.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Zentrale Teleportationsverwaltung für TPA, TPAHERE und Homes: Countdown, Bewegungs-,
 * Combat-, Tod- und Logout-Prüfung. Alle Wege laufen durch {@link #start}.
 */
public final class TeleportManager {

    public enum CancelReason {
        MOVED("tp.cancel-moved"),
        COMBAT("tp.cancel-combat"),
        DEATH("tp.cancel-death"),
        QUIT(null),
        TARGET_OFFLINE("tp.cancel-target-offline"),
        DESTINATION_INVALID("tp.destination-invalid"),
        SHUTDOWN(null);

        private final String messageKey;

        CancelReason(String messageKey) {
            this.messageKey = messageKey;
        }
    }

    /** Liefert das Ziel zum Zeitpunkt des Teleports (null = nicht mehr verfügbar). */
    @FunctionalInterface
    public interface DestinationResolver {
        Location resolve();
    }

    private static final long PERIOD_TICKS = 5L;
    private static final double MOVE_EPSILON_SQUARED = 0.0001; // 1 cm

    private final YumiiTPA plugin;
    private final Map<UUID, Active> active = new HashMap<>();

    public TeleportManager(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    public boolean isTeleporting(UUID id) {
        return active.containsKey(id);
    }

    /**
     * Startet eine Teleportation mit Countdown.
     *
     * @param destinationPlayer Spieler, zu dem teleportiert wird (oder null bei festen Zielen wie Homes)
     * @param combatMessageKey  Nachricht, falls der Spieler im Combat ist
     * @return true, wenn der Countdown gestartet wurde
     */
    public boolean start(Player teleporter, DestinationResolver resolver, UUID destinationPlayer, String combatMessageKey) {
        Messages messages = plugin.messages();
        UUID id = teleporter.getUniqueId();
        if (active.containsKey(id)) {
            messages.send(teleporter, "tp.already");
            return false;
        }
        if (plugin.combat().isInCombat(id)) {
            messages.send(teleporter, combatMessageKey);
            plugin.playSound(teleporter, "deny");
            return false;
        }
        if (teleporter.isDead()) {
            return false;
        }
        if (resolver.resolve() == null) {
            messages.send(teleporter, "tp.destination-invalid");
            return false;
        }

        int delay = plugin.settings().teleportDelaySeconds;
        Active teleport = new Active(id, teleporter.getName(), destinationPlayer, resolver,
                teleporter.getLocation().clone(), delay);
        active.put(id, teleport);

        if (delay <= 0) {
            teleport.complete(teleporter);
            return true;
        }

        messages.send(teleporter, "tp.start", "seconds", String.valueOf(delay), "unit", Text.unit(delay));
        if (destinationPlayer != null) {
            Player other = Bukkit.getPlayer(destinationPlayer);
            if (other != null) {
                messages.send(other, "tp.start-other", "player", teleporter.getName(),
                        "seconds", String.valueOf(delay), "unit", Text.unit(delay));
            }
        }
        teleport.task = Bukkit.getScheduler().runTaskTimer(plugin, teleport, PERIOD_TICKS, PERIOD_TICKS);
        return true;
    }

    /** Sofortige Prüfung bei Bewegungs-Events. */
    public void onMove(Player player, Location to) {
        Active teleport = active.get(player.getUniqueId());
        if (teleport != null && moved(teleport.origin, to)) {
            cancel(player.getUniqueId(), CancelReason.MOVED);
        }
    }

    /** Bricht die Teleportation eines Spielers ab. Gibt true zurück, wenn eine lief. */
    public boolean cancel(UUID id, CancelReason reason) {
        Active teleport = active.remove(id);
        if (teleport == null) {
            return false;
        }
        if (teleport.task != null) {
            teleport.task.cancel();
            teleport.task = null;
        }
        Messages messages = plugin.messages();
        Player player = Bukkit.getPlayer(id);
        if (player != null && reason.messageKey != null) {
            messages.send(player, reason.messageKey);
            plugin.playSound(player, "cancel");
        }
        if (reason != CancelReason.SHUTDOWN && teleport.destination != null) {
            Player other = Bukkit.getPlayer(teleport.destination);
            if (other != null) {
                messages.send(other, "tp.cancelled-other", "player", teleport.teleporterName);
            }
        }
        return true;
    }

    /** Bricht alle Teleportationen ab, deren Ziel dieser Spieler ist (z. B. wenn er den Server verlässt). */
    public void cancelTargeting(UUID destination, CancelReason reason) {
        for (Active teleport : new ArrayList<>(active.values())) {
            if (destination.equals(teleport.destination)) {
                cancel(teleport.teleporter, reason);
            }
        }
    }

    public void shutdown() {
        for (UUID id : new ArrayList<>(active.keySet())) {
            cancel(id, CancelReason.SHUTDOWN);
        }
    }

    private static boolean moved(Location a, Location b) {
        if (!Objects.equals(a.getWorld(), b.getWorld())) {
            return true;
        }
        double dx = a.getX() - b.getX();
        double dy = a.getY() - b.getY();
        double dz = a.getZ() - b.getZ();
        return dx * dx + dy * dy + dz * dz > MOVE_EPSILON_SQUARED;
    }

    private final class Active implements Runnable {
        final UUID teleporter;
        final String teleporterName;
        final UUID destination;
        final DestinationResolver resolver;
        final Location origin;
        final long deadlineMillis;
        int lastShownSeconds;
        BukkitTask task;

        Active(UUID teleporter, String teleporterName, UUID destination, DestinationResolver resolver,
               Location origin, int delaySeconds) {
            this.teleporter = teleporter;
            this.teleporterName = teleporterName;
            this.destination = destination;
            this.resolver = resolver;
            this.origin = origin;
            this.deadlineMillis = System.currentTimeMillis() + delaySeconds * 1000L;
            this.lastShownSeconds = delaySeconds;
        }

        @Override
        public void run() {
            if (active.get(teleporter) != this) {
                if (task != null) {
                    task.cancel();
                }
                return;
            }
            Player player = Bukkit.getPlayer(teleporter);
            if (player == null || !player.isOnline()) {
                cancel(teleporter, CancelReason.QUIT);
                return;
            }
            CancelReason problem = check(player);
            if (problem != null) {
                cancel(teleporter, problem);
                return;
            }
            long now = System.currentTimeMillis();
            if (now >= deadlineMillis) {
                complete(player);
                return;
            }
            int left = (int) Math.ceil((deadlineMillis - now) / 1000.0);
            if (left < lastShownSeconds) {
                lastShownSeconds = left;
                if (left >= 1 && left <= 3) {
                    plugin.messages().send(player, "tp.countdown",
                            "seconds", String.valueOf(left), "unit", Text.unit(left));
                    plugin.playSound(player, "countdown");
                }
            }
        }

        /** Gemeinsame Prüfung (Countdown und letzter Check vor dem Teleport). */
        CancelReason check(Player player) {
            if (player.isDead()) {
                return CancelReason.DEATH;
            }
            if (plugin.combat().isInCombat(teleporter)) {
                return CancelReason.COMBAT;
            }
            if (moved(origin, player.getLocation())) {
                return CancelReason.MOVED;
            }
            if (destination != null) {
                Player other = Bukkit.getPlayer(destination);
                if (other == null || !other.isOnline()) {
                    return CancelReason.TARGET_OFFLINE;
                }
            }
            return null;
        }

        void complete(Player player) {
            CancelReason problem = check(player);
            if (problem != null) {
                cancel(teleporter, problem);
                return;
            }
            Location target = resolver.resolve();
            if (target == null) {
                cancel(teleporter, CancelReason.DESTINATION_INVALID);
                return;
            }
            // Zustand zuerst entfernen, damit nichts doppelt oder nachträglich teleportiert.
            active.remove(teleporter);
            if (task != null) {
                task.cancel();
                task = null;
            }
            player.teleportAsync(target, PlayerTeleportEvent.TeleportCause.PLUGIN).thenAccept(success -> {
                if (!plugin.isEnabled()) {
                    return;
                }
                Bukkit.getScheduler().runTask(plugin, () -> afterTeleport(Boolean.TRUE.equals(success)));
            });
        }

        private void afterTeleport(boolean success) {
            Player player = Bukkit.getPlayer(teleporter);
            Player other = destination == null ? null : Bukkit.getPlayer(destination);
            if (player != null) {
                plugin.messages().send(player, success ? "tp.success" : "tp.failed");
                if (success) {
                    plugin.playSound(player, "success");
                }
            }
            if (success && other != null) {
                plugin.messages().send(other, "tp.success-other", "player", teleporterName);
            }
        }
    }
}
