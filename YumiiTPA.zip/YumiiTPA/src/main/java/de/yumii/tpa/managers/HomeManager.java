package de.yumii.tpa.managers;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.models.Home;
import de.yumii.tpa.models.PlayerHomes;
import de.yumii.tpa.util.HomeNames;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Lädt und speichert Homes (plugins/YumiiTPA/players/&lt;UUID&gt;.yml) und startet
 * Home-Teleportationen über die zentrale {@link TeleportManager}-Logik.
 */
public final class HomeManager {

    private final YumiiTPA plugin;
    private final File directory;
    private final Map<UUID, PlayerHomes> cache = new HashMap<>();

    public HomeManager(YumiiTPA plugin) {
        this.plugin = plugin;
        this.directory = new File(plugin.getDataFolder(), "players");
        if (!directory.exists() && !directory.mkdirs()) {
            plugin.getLogger().warning("Der Ordner " + directory + " konnte nicht erstellt werden.");
        }
    }

    /** Liefert die Homes eines Spielers; lädt sie bei Bedarf von der Festplatte. */
    public PlayerHomes get(UUID id) {
        PlayerHomes cached = cache.get(id);
        if (cached == null) {
            cached = load(id);
            cache.put(id, cached);
        }
        return cached;
    }

    /** Gibt die Daten eines Spielers aus dem Speicher frei (Datei bleibt erhalten). */
    public void unload(UUID id) {
        cache.remove(id);
    }

    private File file(UUID id) {
        return new File(directory, id + ".yml");
    }

    private PlayerHomes load(UUID id) {
        PlayerHomes result = new PlayerHomes();
        File file = file(id);
        if (!file.exists()) {
            return result;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(file);
        } catch (IOException | InvalidConfigurationException ex) {
            plugin.getLogger().log(Level.SEVERE, "Home-Datei von " + id + " ist fehlerhaft und wird gesichert.", ex);
            backupBroken(file);
            return result;
        }
        ConfigurationSection section = yaml.getConfigurationSection("homes");
        if (section == null) {
            return result;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection h = section.getConfigurationSection(key);
            if (h == null) {
                continue;
            }
            String name = h.getString("name", key);
            Home home = new Home(name, h.getString("world", ""),
                    h.getDouble("x", Double.NaN), h.getDouble("y", Double.NaN), h.getDouble("z", Double.NaN),
                    (float) h.getDouble("yaw", 0.0), (float) h.getDouble("pitch", 0.0));
            if (!HomeNames.isValid(name) || !h.isSet("x") || !h.isSet("y") || !h.isSet("z") || !home.isValid()) {
                plugin.getLogger().warning("Ungültiges Home '" + key + "' in " + file.getName() + " wird übersprungen.");
                continue;
            }
            result.putLoaded(home);
        }
        return result;
    }

    private void backupBroken(File file) {
        File backup = new File(directory, file.getName() + ".broken-" + System.currentTimeMillis());
        try {
            Files.move(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Konnte fehlerhafte Datei nicht sichern: " + file, ex);
        }
    }

    /** Speichert die Homes eines Spielers atomar (temporäre Datei, dann ersetzen). */
    public boolean save(UUID id) {
        PlayerHomes homes = cache.get(id);
        if (homes == null) {
            return true;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("version", 1);
        for (Home home : homes.all()) {
            if (!home.isValid()) {
                continue;
            }
            String path = "homes." + HomeNames.key(home.name()) + ".";
            yaml.set(path + "name", home.name());
            yaml.set(path + "world", home.world());
            yaml.set(path + "x", home.x());
            yaml.set(path + "y", home.y());
            yaml.set(path + "z", home.z());
            yaml.set(path + "yaw", (double) home.yaw());
            yaml.set(path + "pitch", (double) home.pitch());
        }
        File target = file(id);
        File temp = new File(directory, id + ".yml.tmp");
        try {
            yaml.save(temp);
            try {
                Files.move(temp.toPath(), target.toPath(),
                        StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Homes von " + id + " konnten nicht gespeichert werden.", ex);
            return false;
        }
    }

    /** Löst ein Home zu einer Location auf; null, wenn die Welt fehlt. */
    public static Location resolve(Home home) {
        World world = Bukkit.getWorld(home.world());
        if (world == null) {
            return null;
        }
        return new Location(world, home.x(), home.y(), home.z(), home.yaw(), home.pitch());
    }

    /** Gemeinsamer Einstieg für /home und die Homes-GUI. */
    public void teleport(Player player, Home home) {
        if (!plugin.settings().homesEnabled) {
            plugin.messages().send(player, "feature-disabled");
            return;
        }
        if (plugin.combat().isInCombat(player.getUniqueId())) {
            plugin.messages().send(player, "home.combat");
            plugin.playSound(player, "deny");
            return;
        }
        if (resolve(home) == null) {
            plugin.messages().send(player, "home.world-missing", "name", home.name());
            return;
        }
        plugin.teleports().start(player, () -> resolve(home), null, "home.combat");
    }
}
