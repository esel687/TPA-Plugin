package de.yumii.tpa.config;

import org.bukkit.configuration.file.FileConfiguration;

/** Unveränderlicher Schnappschuss der Zahlen-/Schalter-Einstellungen mit sicheren Grenzen. */
public final class Settings {

    public static final int MAX_HOME_SLOTS = 10;

    public final boolean tpaEnabled;
    public final boolean combatEnabled;
    public final boolean homesEnabled;
    public final boolean killOnQuit;
    public final int tpaTimeoutSeconds;
    public final int teleportDelaySeconds;
    public final int combatSeconds;
    public final int maxHomes;

    private Settings(FileConfiguration c) {
        this.tpaEnabled = c.getBoolean("systems.tpa", true);
        this.combatEnabled = c.getBoolean("systems.combat", true);
        this.homesEnabled = c.getBoolean("systems.homes", true);
        this.killOnQuit = c.getBoolean("combat.kill-on-quit", false);
        this.tpaTimeoutSeconds = clamp(c.getInt("tpa.request-timeout-seconds", 60), 5, 3600);
        this.teleportDelaySeconds = clamp(c.getInt("teleport.delay-seconds", 5), 0, 60);
        this.combatSeconds = clamp(c.getInt("combat.duration-seconds", 15), 1, 600);
        this.maxHomes = clamp(c.getInt("homes.max", MAX_HOME_SLOTS), 1, MAX_HOME_SLOTS);
    }

    public static Settings load(FileConfiguration config) {
        return new Settings(config);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
