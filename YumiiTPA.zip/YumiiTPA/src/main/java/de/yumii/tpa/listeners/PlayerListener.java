package de.yumii.tpa.listeners;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.managers.TeleportManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

/** Join, Quit, Tod und Bewegung: räumt alle temporären Zustände zuverlässig auf. */
public final class PlayerListener implements Listener {

    private final YumiiTPA plugin;

    public PlayerListener(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.homes().get(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        plugin.teleports().cancel(id, TeleportManager.CancelReason.QUIT);
        plugin.teleports().cancelTargeting(id, TeleportManager.CancelReason.TARGET_OFFLINE);
        plugin.tpa().onQuit(player);
        plugin.combat().onQuit(player);
        plugin.homes().unload(id);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        plugin.teleports().cancel(player.getUniqueId(), TeleportManager.CancelReason.DEATH);
        plugin.combat().end(player);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.teleports().isTeleporting(player.getUniqueId())) {
            return;
        }
        Location to = event.getTo();
        if (to != null) {
            plugin.teleports().onMove(player, to);
        }
    }
}
