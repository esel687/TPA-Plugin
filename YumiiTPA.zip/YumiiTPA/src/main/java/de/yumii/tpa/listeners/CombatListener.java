package de.yumii.tpa.listeners;

import de.yumii.tpa.YumiiTPA;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/** Erkennt Spieler-gegen-Spieler-Schaden (Nahkampf, Pfeile, Tridents, Schneebälle usw.). */
public final class CombatListener implements Listener {

    private final YumiiTPA plugin;

    public CombatListener(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!plugin.settings().combatEnabled) {
            return;
        }
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.getUniqueId().equals(victim.getUniqueId())) {
            return;
        }
        // Nur tatsächlicher Schaden zählt (geblockte Treffer mit 0 Schaden lösen keinen Combat aus).
        if (event.getFinalDamage() <= 0.0) {
            return;
        }
        plugin.combat().tag(attacker, victim);
    }

    private static Player resolveAttacker(Entity damager) {
        if (damager instanceof Player player) {
            return player;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
            return shooter;
        }
        return null;
    }
}
