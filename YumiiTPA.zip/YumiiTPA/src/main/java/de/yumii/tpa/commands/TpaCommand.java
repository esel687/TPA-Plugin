package de.yumii.tpa.commands;

import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.models.TpaRequest;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /tpa, /tpahere, /tpaccept, /tpdeny, /tpcancel und der interne Befehl /tpagui. */
public final class TpaCommand implements TabExecutor {

    private final YumiiTPA plugin;

    public TpaCommand(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "tpa" -> sendRequest(player, args, TpaRequest.Type.TPA, "yumiitpa.tpa", "/tpa <Spieler>");
            case "tpahere" -> sendRequest(player, args, TpaRequest.Type.TPAHERE, "yumiitpa.tpahere", "/tpahere <Spieler>");
            case "tpaccept", "tpdeny" -> openDecision(player, args, command.getName());
            case "tpcancel" -> {
                if (hasPermission(player, "yumiitpa.tpa")) {
                    plugin.tpa().cancelOutgoing(player);
                }
            }
            case "tpagui" -> openGui(player, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private boolean hasPermission(Player player, String permission) {
        if (player.hasPermission(permission)) {
            return true;
        }
        plugin.messages().send(player, "no-permission");
        return false;
    }

    private void sendRequest(Player player, String[] args, TpaRequest.Type type, String permission, String usage) {
        if (!hasPermission(player, permission)) {
            return;
        }
        if (args.length != 1) {
            plugin.messages().send(player, "tpa.usage", "usage", usage);
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.messages().send(player, "player-not-found", "player", args[0]);
            return;
        }
        plugin.tpa().send(player, target, type);
    }

    /** /tpaccept und /tpdeny öffnen die GUI; die Entscheidung fällt erst beim Klick dort. */
    private void openDecision(Player player, String[] args, String commandName) {
        if (!hasPermission(player, "yumiitpa.tpa")) {
            return;
        }
        if (!plugin.settings().tpaEnabled) {
            plugin.messages().send(player, "feature-disabled");
            return;
        }
        TpaRequest request = plugin.tpa().findIncoming(player.getUniqueId(), args.length > 0 ? args[0] : null);
        if (request == null) {
            plugin.messages().send(player, "tpa.no-request");
            return;
        }
        plugin.gui().openTpa(player, request);
    }

    /** Ziel der Klick-Events im Chat. Prüft, dass die Anfrage noch offen und für diesen Spieler ist. */
    private void openGui(Player player, String[] args) {
        if (args.length != 1) {
            plugin.messages().send(player, "tpa.request-invalid");
            return;
        }
        UUID id;
        try {
            id = UUID.fromString(args[0]);
        } catch (IllegalArgumentException ex) {
            plugin.messages().send(player, "tpa.request-invalid");
            return;
        }
        TpaRequest request = plugin.tpa().get(id);
        if (request == null || !request.target().equals(player.getUniqueId())) {
            plugin.messages().send(player, "tpa.request-invalid");
            return;
        }
        plugin.gui().openTpa(player, request);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player) || args.length != 1) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "tpa", "tpahere" -> {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (!online.getUniqueId().equals(player.getUniqueId())) {
                        result.add(online.getName());
                    }
                }
            }
            case "tpaccept", "tpdeny" -> result.addAll(plugin.tpa().incomingSenderNames(player.getUniqueId()));
            default -> {
                return List.of();
            }
        }
        result.removeIf(name -> !name.toLowerCase(Locale.ROOT).startsWith(prefix));
        return result;
    }
}
