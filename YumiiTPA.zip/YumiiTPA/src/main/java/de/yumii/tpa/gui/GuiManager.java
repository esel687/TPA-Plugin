package de.yumii.tpa.gui;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import de.yumii.tpa.YumiiTPA;
import de.yumii.tpa.models.Home;
import de.yumii.tpa.models.PlayerHomes;
import de.yumii.tpa.models.TpaRequest;
import de.yumii.tpa.util.Messages;
import de.yumii.tpa.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/** Baut und öffnet die TPA- und Homes-GUI. Die Inventare erkennen wir an eigenen Holdern. */
public final class GuiManager {

    public static final int SIZE = 27;
    public static final int TPA_HEAD_SLOT = 11;
    public static final int TPA_ACCEPT_SLOT = 13;
    public static final int TPA_DENY_SLOT = 15;
    /** Zwei Reihen à fünf Slots, dazwischen eine Reihe Dekoration. */
    public static final int[] HOME_SLOTS = {2, 3, 4, 5, 6, 20, 21, 22, 23, 24};

    private static final Pattern TEXTURE_HASH = Pattern.compile("[0-9a-fA-F]{40,64}");

    /** Holder der TPA-GUI: ordnet das Inventar eindeutig einer Anfrage und einem Betrachter zu. */
    public static final class TpaHolder implements InventoryHolder {
        private final UUID requestId;
        private final UUID viewer;
        private Inventory inventory;

        TpaHolder(UUID requestId, UUID viewer) {
            this.requestId = requestId;
            this.viewer = viewer;
        }

        public UUID requestId() { return requestId; }

        public UUID viewer() { return viewer; }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    /** Holder der Homes-GUI. */
    public static final class HomesHolder implements InventoryHolder {
        private final UUID viewer;
        private Inventory inventory;

        HomesHolder(UUID viewer) {
            this.viewer = viewer;
        }

        public UUID viewer() { return viewer; }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    private final YumiiTPA plugin;

    public GuiManager(YumiiTPA plugin) {
        this.plugin = plugin;
    }

    public static boolean isPluginInventory(Inventory inventory) {
        if (inventory == null) {
            return false;
        }
        InventoryHolder holder = inventory.getHolder();
        return holder instanceof TpaHolder || holder instanceof HomesHolder;
    }

    // ---------------------------------------------------------------- TPA

    public void openTpa(Player target, TpaRequest request) {
        Messages messages = plugin.messages();
        Player sender = Bukkit.getPlayer(request.sender());
        if (sender == null) {
            messages.send(target, "tpa.sender-offline");
            return;
        }
        TpaHolder holder = new TpaHolder(request.id(), target.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, SIZE, messages.component("gui.tpa.title"));
        holder.inventory = inventory;

        ItemStack glass = decoration("gui.tpa.decoration");
        for (int slot = 0; slot < SIZE; slot++) {
            inventory.setItem(slot, glass.clone());
        }

        String player = sender.getName();
        String loreKey = request.type() == TpaRequest.Type.TPA ? "gui.tpa.sender-lore-tpa" : "gui.tpa.sender-lore-tpahere";
        inventory.setItem(TPA_HEAD_SLOT, senderHead(sender,
                Text.noItalic(Messages.fill(messages.raw("gui.tpa.sender-name"), "player", player)),
                messages.lore(loreKey, "player", player)));
        inventory.setItem(TPA_ACCEPT_SLOT, texturedHead(messages.raw("gui.tpa.accept-texture"),
                Text.noItalic(messages.raw("gui.tpa.accept-name")), messages.lore("gui.tpa.accept-lore")));
        inventory.setItem(TPA_DENY_SLOT, texturedHead(messages.raw("gui.tpa.deny-texture"),
                Text.noItalic(messages.raw("gui.tpa.deny-name")), messages.lore("gui.tpa.deny-lore")));
        target.openInventory(inventory);
    }

    /** Schließt die TPA-GUI eines Spielers, falls sie genau diese Anfrage zeigt. */
    public void closeTpa(UUID playerId, UUID requestId) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) {
            return;
        }
        InventoryHolder holder = player.getOpenInventory().getTopInventory().getHolder();
        if (holder instanceof TpaHolder tpaHolder && tpaHolder.requestId().equals(requestId)) {
            player.closeInventory();
        }
    }

    // -------------------------------------------------------------- Homes

    public void openHomes(Player player) {
        HomesHolder holder = new HomesHolder(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, SIZE, plugin.messages().component("gui.homes.title"));
        holder.inventory = inventory;
        populateHomes(inventory, player);
        player.openInventory(inventory);
    }

    /** Aktualisiert eine offene Homes-GUI nach Änderungen an den Home-Daten. */
    public void refreshHomes(Player player) {
        Inventory top = player.getOpenInventory().getTopInventory();
        if (top.getHolder() instanceof HomesHolder) {
            populateHomes(top, player);
        }
    }

    private void populateHomes(Inventory inventory, Player player) {
        Messages messages = plugin.messages();
        ItemStack glass = decoration("gui.homes.decoration");
        for (int slot = 0; slot < SIZE; slot++) {
            inventory.setItem(slot, glass.clone());
        }
        PlayerHomes playerHomes = plugin.homes().get(player.getUniqueId());
        List<Home> homes = playerHomes.all();
        int max = plugin.settings().maxHomes;

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (i < homes.size()) {
                inventory.setItem(HOME_SLOTS[i], occupiedItem(homes.get(i)));
            } else if (i < max) {
                inventory.setItem(HOME_SLOTS[i], item(Material.RED_BED,
                        messages.raw("gui.homes.free-name"), messages.lore("gui.homes.free-lore")));
            }
        }
    }

    private ItemStack occupiedItem(Home home) {
        Messages messages = plugin.messages();
        List<Component> lore = messages.lore("gui.homes.occupied-lore",
                "name", home.name(),
                "world", home.world(),
                "x", coordinate(home.x()),
                "y", coordinate(home.y()),
                "z", coordinate(home.z()));
        if (Bukkit.getWorld(home.world()) == null) {
            lore.add(Text.noItalic(messages.raw("gui.homes.world-missing-line")));
        }
        return item(Material.LIME_BED,
                Messages.fill(messages.raw("gui.homes.occupied-name"), "name", home.name()), lore);
    }

    private static String coordinate(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    // ------------------------------------------------------------ Helfer

    private ItemStack decoration(String path) {
        Material material = Material.matchMaterial(plugin.messages().raw(path));
        if (material == null || !material.isItem()) {
            material = Material.BLACK_STAINED_GLASS_PANE;
        }
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(" "));
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack item(Material material, String name, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.noItalic(name));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack senderHead(Player sender, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) stack.getItemMeta();
        meta.setPlayerProfile(sender.getPlayerProfile());
        meta.displayName(name);
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Player-Head mit Textur anhand eines Hashes von textures.minecraft.net. */
    private ItemStack texturedHead(String textureHash, Component name, List<Component> lore) {
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) stack.getItemMeta();
        if (textureHash != null && TEXTURE_HASH.matcher(textureHash).matches()) {
            try {
                PlayerProfile profile = Bukkit.createProfile(
                        UUID.nameUUIDFromBytes(("yumiitpa:" + textureHash).getBytes(StandardCharsets.UTF_8)), "YumiiTPA");
                String json = "{\"textures\":{\"SKIN\":{\"url\":\"http://textures.minecraft.net/texture/"
                        + textureHash + "\"}}}";
                profile.setProperty(new ProfileProperty("textures",
                        Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8))));
                meta.setPlayerProfile(profile);
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Kopf-Textur konnte nicht gesetzt werden: " + ex.getMessage());
            }
        }
        meta.displayName(name);
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Schließt alle offenen Plugin-GUIs (beim Deaktivieren). */
    public void closeAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isPluginInventory(player.getOpenInventory().getTopInventory())) {
                player.closeInventory();
            }
        }
    }
}
